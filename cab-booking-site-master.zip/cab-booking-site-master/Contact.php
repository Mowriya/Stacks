<?php
session_start();
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con, 'test');
$Name = $_POST['name'];
$Phone = $_POST['phone'];
$Mail = $_POST['mail'];
$Plocation = $_POST['plocation'];
$Dlocation = $_POST['dlocation'];
$Date = $_POST['date'];
$Time = $_POST['time'];

 $reg= "insert into contact(name , phnumber , email , pickuplocation , droplocation , date , time) values ('$Name' , '$Phone' , '$Mail' , '$Plocation' , '$Dlocation' , '$Date' , '$Time')";
 mysqli_query($con, $reg);
header('location:index.html');


?>