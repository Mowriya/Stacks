package p1;
class JumbledGame{
final int choice;
publi static void main(String []args){
JumbledGame obj1=new JumbledGame();
System.ouut.println(obj1.choice);
}
}