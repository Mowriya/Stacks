﻿<?php
$con=mysqli_connect("localhost","root","","test");
if(isset($_POST['submit']))
{
	$Mail = $_POST['email'];
        $Password = $_POST['password'];
	$q = mysqli_query($con,"select * from signup where email = '{$Mail}' and password = '{$Password}'");
if(mysqli_num_rows($q) >0)
	{
 header('location:contact.html');

}
else
{
	 header('location:login.php');
          echo "invalid credientials";
}
}
?>


<html>
    <head>
            <meta name="viewport" content="width=device-width, initial-scale=1">
                <title>
                   Ryde 4 U
                </title>
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
            <link rel="stylesheet" href="css/style.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
  <nav class="navbar navbar-dark bg-dark1">
      <!-- Navbar content -->

    <div id="mySidepanel" class="sidepanel">
     <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
           <a href="index.html">Home</a>
           <a href="About.html">About</a>
           <a href="service.html">Services</a>
           <a href="client.html">Clients</a>
           <a href="contact.html">Book Cab</a>
    </div>
      <button class="openbtn" onclick="openNav()">&#9776;&nbsp;&nbsp; Ryde 4 You</button>

    <div class="logo">
         <img src="img/logo1.png" alt="Avatar" style="width:200px";>
     </div>
    
     <i class="fa fa-map-marker" style="background-color: white; color:black;">
      Bangalore
      </i>
     <i class="fa fa-phone" style="background-color: white; color:black;">
          9047393929
     </i>
      <a href="signup.html">
     <i class="fa fa-sign-in" style="background-color: white; color:black;">
      SIGNUP
      </i></a>
  </nav>

<div class="card bg-dark text-white">
  <img class="card-img" src="img/dark2.jpg" alt="Card image">
  <div class="card-img-overlay">
  <div class="container-fluids">
 
  <form  method="post">
  <div class="form-group">
    <label>Email address</label>
    <input type="email" class="form-control" name="email" id="email" placeholder="Enter email" required>
    <small id="emailHelp">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label>Password</label>
    <input type="password" class="form-control" name="password" placeholder="Password" required>
  </div>
  <h5>To create a new account <a href="signup.html" style="color:blue;">sign up</a></h5>
  <br><br><br>
  <input type="submit" name="submit"  value="Login" />
</form>
  </div>
  </div>
  </div>

 
     

           <div class="jumbotron jumbotron-fluid">
                         <div class="container">                                          
                           <div class ="row"> 
                              
                              &nbsp;&nbsp;&nbsp;
                                <div class="card" style="width: 14rem;">
                                    <div class="card-body">
                                    <i class="fa fa-phone"></i>
                                       <h5 class="card-title">Phone</h5>                                           
                                                       <p class="card-text"><a href="tel:T@gmail.com">044- 24732020</a></p>
                                    </div>
                                </div>
                                &nbsp;&nbsp;&nbsp;
                                <div class="card" style="width: 14rem;">
                                    <div class="card-body">
                                    <i class="fa fa-map-marker"></i>
                                       <h5 class="card-title">Find us</h5>                                           
                                                       <p class="card-text">abc street,<br> bangalore ,<br>india.</p>
                                    </div>
                                </div> 
                                &nbsp;&nbsp;&nbsp;   
                                <div class="card" style="width: 14rem;">
                                    <div class="card-body">
                                   
                                                        
                                                             <div class="col">
                                                                       <i class="fa fa-twitter">&nbsp; Twitter</i>
                                                              </div>&nbsp;&nbsp;&nbsp;
                                                          <div class="col order-12">
                                                                         <i class="fa fa-facebook">&nbsp; Face book</i>
                                                           </div>&nbsp;&nbsp;&nbsp;
                                                             <div class="col order-1">
                                                                       <i class="fa fa-instagram">&nbsp; Instagram</i>
                                                               </div>
                                                       
                           </div>
                                     
                                    </div>
                                </div>                     
                      </div>
                    </div>
                 </div>
                            
  
    
  <div>
<center>
<button type="button" class="btn btn-secondary"><a href="index.html">Home</a></button>
    <button type="button" class="btn btn-secondary"><a href="About.html">About Us</a></button>
    <button type="button" class="btn btn-secondary"><a href="contact.html">Book Cab</a></button>
    <button type="button" class="btn btn-secondary"><a href="signup.html">Register </a></button>
    <button type="button" class="btn btn-secondary"><a href="client.html">Packages</a></button>
    <button type="button" class="btn btn-secondary"><a href="service.html">Service</a></button>
  </div></center>

            





                          
                  <script  src="js/index.js"></script>
    </body>
</html>
