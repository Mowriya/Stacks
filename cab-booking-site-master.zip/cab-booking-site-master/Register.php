<?php
session_start();
$con = mysqli_connect('localhost','root','');
mysqli_select_db($con, 'test');
$Name = $_POST['nam'];
$Mail = $_POST['mail'];
$Password = $_POST['pass'];
$Phone = $_POST['phn'];
$City = $_POST['cy'];
$State = $_POST['st'];
$Zip = $_POST['zp'];
$s = " select * from signup where name = '$Name' ";
$result = mysqli_query($con, $s);
$num = mysqli_num_rows($result);
if($num == true){
$msg = "user exsists";
header('location:signup.html');
}
else{
 $reg= "insert into signup(name , email , Password , Phnumber , city , state , zip) values ('$Name' , '$Mail' , '$Password' , '$Phone' , '$City' , '$State' , '$Zip')";
 mysqli_query($con, $reg);
header('location:login.php');
}
?>